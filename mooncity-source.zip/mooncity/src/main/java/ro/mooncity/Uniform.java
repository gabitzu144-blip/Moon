package ro.mooncity;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class Uniform {
    private Uniform() {}

    public static boolean isPolice(ItemStack s) {
        return s.is(MoonCity.POLICE_CAP.get()) || s.is(MoonCity.POLICE_SHIRT.get()) || s.is(MoonCity.POLICE_VEST.get())
                || s.is(MoonCity.POLICE_PANTS.get()) || s.is(MoonCity.POLICE_BOOTS.get());
    }

    /** La Off Duty: hainele de serviciu se scot automat. */
    public static void strip(ServerPlayer p) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = p.getItemBySlot(slot);
            if (isPolice(st)) {
                p.setItemSlot(slot, ItemStack.EMPTY);
                if (!p.getInventory().add(st)) p.drop(st, false);
            }
        }
    }

    public static void give(ServerPlayer p) {
        for (var it : new net.minecraft.world.item.Item[]{MoonCity.POLICE_CAP.get(), MoonCity.POLICE_SHIRT.get(),
                MoonCity.POLICE_VEST.get(), MoonCity.POLICE_PANTS.get(), MoonCity.POLICE_BOOTS.get()}) {
            ItemStack st = new ItemStack(it);
            if (!p.getInventory().add(st)) p.drop(st, false);
        }
    }
}
