package ro.mooncity;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class Events {
    public static final int COMA_TICKS = 20 * 60 * 5; // 5 minute

    @SubscribeEvent
    public void nameFormat(PlayerEvent.NameFormat e) {
        String p = PlayerData.prefix(e.getEntity());
        if (!p.isEmpty()) {
            e.setDisplayname(Component.literal("[" + p + "] ").withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE)
                    .append(e.getDisplayname()));
        }
    }

    @SubscribeEvent
    public void join(PlayerEvent.PlayerLoggedInEvent e) {
        e.getEntity().refreshDisplayName();
        if (e.getEntity() instanceof ServerPlayer sp) Net.sync(sp);
    }

    @SubscribeEvent
    public void attack(LivingAttackEvent e) {
        if (e.getEntity() instanceof Player p && PlayerData.inComa(p)
                && !e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void death(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return; // /kill, void, expirare coma
        if (PlayerData.inComa(sp)) return;
        e.setCanceled(true);
        sp.setHealth(1.0F);
        PlayerData.setComa(sp, COMA_TICKS);
        applyComaEffects(sp);
        sp.sendSystemMessage(Component.literal("Esti in coma! Astepti un medic cu MEDKIT.")
                .withStyle(net.minecraft.ChatFormatting.RED));
    }

    private static void applyComaEffects(ServerPlayer sp) {
        int d = COMA_TICKS + 40;
        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, d, 255, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.JUMP, d, 128, false, false));
        sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, d, 255, false, false));
    }

    public static void revive(ServerPlayer sp) {
        PlayerData.setComa(sp, 0);
        sp.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        sp.removeEffect(MobEffects.JUMP);
        sp.removeEffect(MobEffects.WEAKNESS);
        sp.setHealth(10.0F);
        sp.sendSystemMessage(Component.literal("Ai fost salvat!").withStyle(net.minecraft.ChatFormatting.GREEN));
    }

    @SubscribeEvent
    public void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp)) return;
        if (sp.tickCount % 20 == 0) Net.sync(sp);
        int jt = PlayerData.jail(sp);
        if (jt > 0) {
            PlayerData.setJail(sp, jt - 1);
            if (jt - 1 == 0) JailCommand.release(sp);
            else if (sp.tickCount % 20 == 0)
                sp.displayClientMessage(Component.literal("JAIL: " + ((jt - 1) / 20 / 60) + "m " + (((jt - 1) / 20) % 60) + "s ramase")
                        .withStyle(net.minecraft.ChatFormatting.GOLD), true);
        }
        int c = PlayerData.coma(sp);
        if (c <= 0) return;
        c--;
        PlayerData.setComa(sp, c);
        if (c % 20 == 0) {
            int s = c / 20;
            sp.displayClientMessage(Component.literal("ESTI IN COMA " + (s / 60) + "m " + (s % 60) + "s")
                    .withStyle(net.minecraft.ChatFormatting.RED), true);
        }
        if (c == 0) {
            sp.hurt(sp.damageSources().genericKill(), Float.MAX_VALUE);
        }
    }

    @SubscribeEvent
    public void started(net.minecraftforge.event.server.ServerStartedEvent e) { WorldData.loadAll(e.getServer()); }

    @SubscribeEvent
    public void stopping(net.minecraftforge.event.server.ServerStoppingEvent e) { WorldData.saveAll(e.getServer()); }
}
