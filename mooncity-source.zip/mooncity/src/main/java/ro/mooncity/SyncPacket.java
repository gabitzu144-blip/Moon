package ro.mooncity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncPacket {
    public final int id, online, playSeconds;
    public final long cash, bank;
    public final boolean duty;

    public SyncPacket(int id, long cash, long bank, boolean duty, int online, int playSeconds) {
        this.id = id; this.cash = cash; this.bank = bank; this.duty = duty;
        this.online = online; this.playSeconds = playSeconds;
    }

    public static void encode(SyncPacket p, FriendlyByteBuf b) {
        b.writeInt(p.id); b.writeLong(p.cash); b.writeLong(p.bank);
        b.writeBoolean(p.duty); b.writeInt(p.online); b.writeInt(p.playSeconds);
    }

    public static SyncPacket decode(FriendlyByteBuf b) {
        return new SyncPacket(b.readInt(), b.readLong(), b.readLong(), b.readBoolean(), b.readInt(), b.readInt());
    }

    public static void handle(SyncPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.client.ClientData.set(p)));
        ctx.get().setPacketHandled(true);
    }
}
