package ro.mooncity;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.Villager;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** op 0 = incepe jobul, op 1 = rezultat minijoc */
public class JobPacket {
    public final int op; public final String job; public final boolean success;
    public JobPacket(int op, String job, boolean success) { this.op = op; this.job = job; this.success = success; }
    public static void encode(JobPacket p, FriendlyByteBuf b) { b.writeInt(p.op); b.writeUtf(p.job, 20); b.writeBoolean(p.success); }
    public static JobPacket decode(FriendlyByteBuf b) { return new JobPacket(b.readInt(), b.readUtf(20), b.readBoolean()); }

    public static void handle(JobPacket p, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sp == null) return;
            long pay = p.job.equals("constructor") ? 1500 : p.job.equals("sudor") ? 1200 : 0;
            if (pay == 0) return;
            if (p.op == 0) {
                boolean near = !sp.serverLevel().getEntitiesOfClass(Villager.class, sp.getBoundingBox().inflate(8),
                        v -> v.getPersistentData().getBoolean("mc_npc") && v.getPersistentData().getString("mc_job").equals(p.job)).isEmpty();
                if (!near) return;
                PlayerData.setJob(sp, p.job, sp.level().getGameTime());
            } else {
                if (!PlayerData.jobName(sp).equals(p.job)) return;
                long el = sp.level().getGameTime() - PlayerData.jobStart(sp);
                PlayerData.clearJob(sp);
                if (!p.success) {
                    sp.sendSystemMessage(Component.literal("Ai ratat. Mai incearca!").withStyle(ChatFormatting.RED));
                    return;
                }
                if (el < 8 * 20 || el > 5 * 60 * 20) {
                    sp.sendSystemMessage(Component.literal("Rezultat invalid.").withStyle(ChatFormatting.RED));
                    return;
                }
                PlayerData.setBank(sp, PlayerData.bank(sp) + pay);
                Net.sync(sp);
                sp.sendSystemMessage(Component.literal("Job terminat: +$" + pay + " in banca.").withStyle(ChatFormatting.GREEN));
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
