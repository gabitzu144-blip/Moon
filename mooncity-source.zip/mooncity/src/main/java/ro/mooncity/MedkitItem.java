package ro.mooncity;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class MedkitItem extends Item {
    public MedkitItem(Properties p) { super(p); }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player user, LivingEntity target, InteractionHand hand) {
        if (target instanceof ServerPlayer t && PlayerData.inComa(t)) {
            if (!user.level().isClientSide) {
                Events.revive(t);
                if (!user.getAbilities().instabuild) stack.shrink(1);
            }
            return InteractionResult.sidedSuccess(user.level().isClientSide);
        }
        return InteractionResult.PASS;
    }
}
