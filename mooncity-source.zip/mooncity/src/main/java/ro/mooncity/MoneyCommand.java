package ro.mooncity;

import com.mojang.brigadier.arguments.LongArgumentType;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class MoneyCommand {
    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        // /money <jucator> <cash|bank> <set|add> <suma>
        var root = literal("money").requires(s -> s.hasPermission(2));
        var target = argument("jucator", EntityArgument.player());
        for (String type : new String[]{"cash", "bank"}) {
            for (String op : new String[]{"set", "add", "take"}) {
                target.then(literal(type).then(literal(op).then(
                        argument("suma", LongArgumentType.longArg(0)).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                            long v = LongArgumentType.getLong(c, "suma");
                            boolean cash = type.equals("cash");
                            long cur = cash ? PlayerData.cash(t) : PlayerData.bank(t);
                            long nv = op.equals("set") ? v : op.equals("add") ? cur + v : Math.max(0, cur - v);
                            if (cash) PlayerData.setCash(t, nv); else PlayerData.setBank(t, nv);
                            Net.sync(t);
                            c.getSource().sendSuccess(() -> Component.literal(
                                    t.getName().getString() + " " + type + " = $" + nv), true);
                            return 1;
                        }))));
            }
        }
        e.getDispatcher().register(root.then(target));
    }
}
