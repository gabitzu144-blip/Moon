package ro.mooncity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public class PoliceMaterial implements ArmorMaterial {
    public static final PoliceMaterial SHIRT = new PoliceMaterial("mooncity:police", 250, 1, 2, 3, 1);
    public static final PoliceMaterial VEST = new PoliceMaterial("mooncity:police_vest", 450, 1, 2, 6, 1);

    private final String name; private final int dur, h, l, c, b;

    private PoliceMaterial(String name, int dur, int h, int l, int c, int b) {
        this.name = name; this.dur = dur; this.h = h; this.l = l; this.c = c; this.b = b;
    }

    @Override public int getDurabilityForType(ArmorItem.Type t) { return dur; }
    @Override public int getDefenseForType(ArmorItem.Type t) {
        return switch (t) { case HELMET -> h; case CHESTPLATE -> c; case LEGGINGS -> l; case BOOTS -> b; };
    }
    @Override public int getEnchantmentValue() { return 10; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_LEATHER; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
    @Override public String getName() { return name; }
    @Override public float getToughness() { return 0; }
    @Override public float getKnockbackResistance() { return 0; }
}
