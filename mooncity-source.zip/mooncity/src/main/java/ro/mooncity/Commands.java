package ro.mooncity;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class Commands {
    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();

        // /revive <jucator>
        d.register(literal("revive").requires(s -> s.hasPermission(2))
                .then(argument("jucator", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                    Events.revive(t);
                    c.getSource().sendSuccess(() -> Component.literal("L-ai revivat pe " + t.getName().getString()), true);
                    return 1;
                })));

        // /grad set <jucator> <prefix>   |   /grad clear <jucator>
        d.register(literal("grad").requires(s -> s.hasPermission(2))
                .then(literal("set").then(argument("jucator", EntityArgument.player())
                        .then(argument("prefix", StringArgumentType.greedyString()).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                            String p = StringArgumentType.getString(c, "prefix");
                            PlayerData.setPrefix(t, p);
                            t.refreshDisplayName();
                            c.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " are gradul: " + p), true);
                            return 1;
                        }))))
                .then(literal("clear").then(argument("jucator", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                    PlayerData.setPrefix(t, "");
                    t.refreshDisplayName();
                    return 1;
                }))));

        // /id set <jucator> <numar>
        d.register(literal("id").requires(s -> s.hasPermission(2))
                .then(literal("set").then(argument("jucator", EntityArgument.player())
                        .then(argument("numar", IntegerArgumentType.integer(1, 99999)).executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                            int n = IntegerArgumentType.getInteger(c, "numar");
                            if (PlayerData.idTaken(t, n)) {
                                c.getSource().sendFailure(Component.literal("ID-ul " + n + " e deja folosit."));
                                return 0;
                            }
                            PlayerData.setId(t, n);
                            Net.sync(t);
                            c.getSource().sendSuccess(() -> Component.literal("ID setat: " + n), true);
                            return 1;
                        })))));

        // /duty on|off
        d.register(literal("duty")
                .then(literal("on").executes(c -> duty(c.getSource(), true)))
                .then(literal("off").executes(c -> duty(c.getSource(), false))));
    }

    private int duty(CommandSourceStack s, boolean on) {
        ServerPlayer p = s.getPlayer();
        if (p == null) return 0;
        PlayerData.setDuty(p, on);
        if (!on) Uniform.strip(p);
        Net.sync(p);
        s.sendSuccess(() -> Component.literal(on ? "Esti ON DUTY." : "Esti OFF DUTY."), false);
        return 1;
    }
}
