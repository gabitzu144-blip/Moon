package ro.mooncity;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Garage {
    public static final Map<String, Long> PRICE = new LinkedHashMap<>();
    static {
        PRICE.put("nissan_370z", 60000L);
        PRICE.put("sprinter", 70000L);
        PRICE.put("bmw_m3", 80000L);
        PRICE.put("f150_raptor", 90000L);
        PRICE.put("bmw_x6", 110000L);
        PRICE.put("bmw_m5", 120000L);
        PRICE.put("audi_r8", 150000L);
        PRICE.put("g63", 200000L);
        PRICE.put("maybach", 250000L);
        PRICE.put("super_car", 300000L);
        PRICE.put("spy_hypersport", 500000L);
        PRICE.put("koenigsegg_one", 900000L);
        PRICE.put("lamborghini_venevo", 1000000L);
        PRICE.put("charger_police", 0L);   // doar staff
        PRICE.put("vw_police", 0L);        // doar staff
    }

    private Garage() {}

    public static boolean nearBlock(ServerPlayer sp) {
        BlockPos pos = sp.blockPosition();
        for (BlockPos b : BlockPos.betweenClosed(pos.offset(-8, -4, -8), pos.offset(8, 4, 8)))
            if (sp.level().getBlockState(b).is(MoonCity.GARAGE.get())) return true;
        return false;
    }

    public static void sendList(ServerPlayer sp) {
        List<GarageListPacket.Entry> l = new ArrayList<>();
        for (String id : PlayerData.garageIds(sp)) l.add(new GarageListPacket.Entry(id, PlayerData.carOut(sp, id)));
        Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new GarageListPacket(l));
    }

    public static String take(ServerPlayer sp, String id) {
        if (!PlayerData.hasCar(sp, id)) return "Nu ai masina asta.";
        if (PlayerData.carOut(sp, id)) return "Masina e deja scoasa. Parcheaz-o mai intai.";
        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation("mooncityvehicles", id));
        if (it == null || it == Items.AIR) return "Masina nu exista (lipseste mod-ul mooncityvehicles).";
        ItemStack st = new ItemStack(it);
        if (!sp.getInventory().add(st)) sp.drop(st, false);
        PlayerData.setCarOut(sp, id, true);
        return null;
    }

    public static String park(ServerPlayer sp, String id) {
        if (!PlayerData.hasCar(sp, id) || !PlayerData.carOut(sp, id)) return "Masina nu e scoasa.";
        ResourceLocation want = new ResourceLocation("mooncityvehicles", id);
        AABB box = sp.getBoundingBox().inflate(10);
        for (Entity e : sp.level().getEntities((Entity) null, box, x -> want.equals(ForgeRegistries.ENTITY_TYPES.getKey(x.getType())))) {
            if (e.isVehicle()) continue;
            e.discard();
            PlayerData.setCarOut(sp, id, false);
            return null;
        }
        Item it = ForgeRegistries.ITEMS.getValue(want);
        if (it != null) {
            for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
                ItemStack s = sp.getInventory().getItem(i);
                if (s.is(it)) { s.shrink(1); PlayerData.setCarOut(sp, id, false); return null; }
            }
        }
        return "Nu e nicio masina de acest tip in apropiere (10 blocuri).";
    }

    public static String sell(ServerPlayer sp, String id) {
        if (!PlayerData.hasCar(sp, id)) return "Nu ai masina asta.";
        if (PlayerData.carOut(sp, id)) return "Parcheaz-o mai intai.";
        long refund = PRICE.getOrDefault(id, 0L) * 60 / 100;
        PlayerData.removeCar(sp, id);
        PlayerData.setBank(sp, PlayerData.bank(sp) + refund);
        return null;
    }

    public static String buy(ServerPlayer sp, String id) {
        Long price = PRICE.get(id);
        if (price == null || price <= 0) return "Masina nu se poate cumpara.";
        if (PlayerData.hasCar(sp, id)) return "O ai deja.";
        if (PlayerData.bank(sp) < price) return "Fonduri insuficiente in banca ($" + price + ").";
        PlayerData.setBank(sp, PlayerData.bank(sp) - price);
        PlayerData.addCar(sp, id);
        return null;
    }
}
