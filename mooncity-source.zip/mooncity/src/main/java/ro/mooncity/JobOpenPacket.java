package ro.mooncity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class JobOpenPacket {
    public final String job, npc;
    public JobOpenPacket(String job, String npc) { this.job = job; this.npc = npc; }
    public static void encode(JobOpenPacket p, FriendlyByteBuf b) { b.writeUtf(p.job, 20); b.writeUtf(p.npc, 60); }
    public static JobOpenPacket decode(FriendlyByteBuf b) { return new JobOpenPacket(b.readUtf(20), b.readUtf(60)); }
    public static void handle(JobOpenPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.client.Screens.openJob(p.job, p.npc)));
        ctx.get().setPacketHandled(true);
    }
}
