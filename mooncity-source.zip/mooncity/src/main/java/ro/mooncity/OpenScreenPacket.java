package ro.mooncity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OpenScreenPacket {
    public final int screen; public final String iban;
    public OpenScreenPacket(int screen, String iban) { this.screen = screen; this.iban = iban; }
    public static void encode(OpenScreenPacket p, FriendlyByteBuf b) { b.writeInt(p.screen); b.writeUtf(p.iban, 40); }
    public static OpenScreenPacket decode(FriendlyByteBuf b) { return new OpenScreenPacket(b.readInt(), b.readUtf(40)); }
    public static void handle(OpenScreenPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ro.mooncity.client.Screens.open(p.screen, p.iban)));
        ctx.get().setPacketHandled(true);
    }
}
