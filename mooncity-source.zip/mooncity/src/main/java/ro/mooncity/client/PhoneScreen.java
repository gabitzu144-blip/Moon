package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ro.mooncity.BankPacket;
import ro.mooncity.Net;

/** Telefon MoonCity: portret, cu transfer IBAN. */
public class PhoneScreen extends Screen {
    private final String iban;
    private EditBox target, amount;
    private long holdStart = -1;      // amprenta: tine apasat 3 secunde
    private boolean unlocked = false;
    private Button hold;

    public PhoneScreen(String iban) { super(Component.literal("Telefon")); this.iban = iban; }

    private int px() { return width / 2 - 80; }
    private int py() { return height / 2 - 130; }

    @Override
    protected void init() {
        int x = px() + 12, y = py();
        if (!unlocked) return;
        target = new EditBox(font, x, y + 84, 136, 18, Component.literal("IBAN"));
        target.setHint(Component.literal("IBAN destinatar"));
        target.setMaxLength(24);
        addRenderableWidget(target);
        amount = new EditBox(font, x, y + 128, 136, 18, Component.literal("Suma"));
        amount.setHint(Component.literal("Suma ($)"));
        amount.setMaxLength(12);
        addRenderableWidget(amount);
        addRenderableWidget(Button.builder(Component.literal("CONFIRMA TRANSFERUL"), b -> {
            String s = amount.getValue().trim();
            if (s.matches("\\d{1,12}") && !target.getValue().isBlank())
                Net.CH.sendToServer(new BankPacket(2, Long.parseLong(s), target.getValue()));
        }).bounds(x, y + 170, 136, 20).build());
        addRenderableWidget(Button.builder(Component.literal("< Inapoi"), b -> onClose()).bounds(x, y + 214, 136, 18).build());
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (!unlocked && inFinger(mx, my)) { holdStart = System.currentTimeMillis(); return true; }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        holdStart = -1;
        return super.mouseReleased(mx, my, btn);
    }

    private boolean inFinger(double mx, double my) {
        int cx = width / 2, cy = py() + 150;
        return Math.abs(mx - cx) < 32 && Math.abs(my - cy) < 32;
    }

    @Override
    public void tick() {
        super.tick();
        if (!unlocked && holdStart > 0 && System.currentTimeMillis() - holdStart >= 3000) {
            unlocked = true;
            holdStart = -1;
            rebuildWidgets();
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = px(), y = py();
        // corp telefon (portret, ca un telefon, nu ca o carte)
        g.fill(x - 4, y - 4, x + 164, y + 244, 0xFF0A0618);
        g.renderOutline(x - 4, y - 4, 168, 248, 0xFF7B5CE6);
        g.fill(x + 56, y - 1, x + 104, y + 3, 0xFF000000);   // notch
        g.fill(x, y + 8, x + 160, y + 240, 0xFF100A24);
        g.drawString(font, "MoonCity", x + 12, y + 12, 0xFFFFFFFF, false);
        if (!unlocked) {
            g.drawCenteredString(font, "MOONCITY", x + 80, y + 40, 0xFFB79CFF);
            int cx = width / 2, cy = y + 150;
            g.renderOutline(cx - 28, cy - 28, 56, 56, 0xFF7B5CE6);
            if (holdStart > 0) {
                float f = Math.min(1f, (System.currentTimeMillis() - holdStart) / 3000f);
                g.fill(cx - 26, cy + 26 - (int) (52 * f), cx + 26, cy + 26, 0x807B5CE6);
            }
            g.drawCenteredString(font, "Tine apasat pe amprenta", x + 80, y + 200, 0xFFA99BE0);
            g.drawCenteredString(font, "3 secunde", x + 80, y + 210, 0xFFA99BE0);
        } else {
            g.drawString(font, "Transfer prin IBAN", x + 12, y + 24, 0xFFA99BE0, false);
            g.drawString(font, "IBAN-UL TAU", x + 12, y + 40, 0xFFA99BE0, false);
            g.drawString(font, iban, x + 12, y + 52, 0xFFB79CFF, false);
            g.drawString(font, "IBAN DESTINATAR", x + 12, y + 74, 0xFFA99BE0, false);
            g.drawString(font, "SUMA", x + 12, y + 118, 0xFFA99BE0, false);
            g.drawString(font, "Disponibil: $" + String.format("%,d", ClientData.bank), x + 12, y + 150, 0xFFFFFFFF, false);
            g.drawString(font, "Transferurile sunt instant", x + 12, y + 196, 0xFF8F84C8, false);
            g.drawString(font, "si definitive.", x + 12, y + 205, 0xFF8F84C8, false);
        }
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
