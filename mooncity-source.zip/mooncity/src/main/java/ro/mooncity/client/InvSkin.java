package ro.mooncity.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ro.mooncity.MoonCity;

@Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class InvSkin {
    @SubscribeEvent
    public static void open(ScreenEvent.Opening e) {
        if (e.getNewScreen() != null && e.getNewScreen().getClass() == InventoryScreen.class) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) e.setNewScreen(new MoonInventoryScreen(mc.player));
        }
    }
}
