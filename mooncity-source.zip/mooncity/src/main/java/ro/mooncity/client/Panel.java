package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;

final class Panel {
    private Panel() {}
    static void draw(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xE0100A24);
        g.renderOutline(x, y, w, h, 0xFF7B5CE6);
    }
}
