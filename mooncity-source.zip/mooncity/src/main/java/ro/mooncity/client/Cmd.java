package ro.mooncity.client;

import net.minecraft.client.Minecraft;

public final class Cmd {
    private Cmd() {}
    public static void run(String c) {
        var p = Minecraft.getInstance().player;
        if (p != null) p.connection.sendCommand(c);
    }
}
