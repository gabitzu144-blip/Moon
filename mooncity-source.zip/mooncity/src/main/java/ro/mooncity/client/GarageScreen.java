package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;
import ro.mooncity.Garage;
import ro.mooncity.GarageActionPacket;
import ro.mooncity.GarageListPacket;
import ro.mooncity.Net;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GarageScreen extends Screen {
    private List<GarageListPacket.Entry> entries;
    private boolean shop = false;
    private String sel = null;
    private final Map<String, ItemStack> icons = new HashMap<>();

    public GarageScreen(List<GarageListPacket.Entry> l) { super(Component.literal("Garaj")); this.entries = l; }

    public void update(List<GarageListPacket.Entry> l) { this.entries = l; rebuildWidgets(); }

    private int x0() { return width / 2 - 220; }
    private int y0() { return height / 2 - 120; }

    private List<String> ids() {
        if (shop) return new ArrayList<>(Garage.PRICE.keySet());
        List<String> r = new ArrayList<>();
        for (var e : entries) r.add(e.id);
        return r;
    }

    private GarageListPacket.Entry find(String id) {
        for (var e : entries) if (e.id.equals(id)) return e;
        return null;
    }

    private ItemStack icon(String id) {
        return icons.computeIfAbsent(id, k -> {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation("mooncityvehicles", k));
            return it == null || it == Items.AIR ? ItemStack.EMPTY : new ItemStack(it);
        });
    }

    private String nameOf(String id) { return Component.translatable("item.mooncityvehicles." + id).getString(); }

    private void send(int op) { if (sel != null) Net.CH.sendToServer(new GarageActionPacket(op, sel)); }

    @Override
    protected void init() {
        int x0 = x0(), y0 = y0();
        addRenderableWidget(Button.builder(Component.literal(shop ? "GARAJ" : "> GARAJ"), b -> { shop = false; sel = null; rebuildWidgets(); }).bounds(x0 + 8, y0 + 8, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal(shop ? "> MAGAZIN" : "MAGAZIN"), b -> { shop = true; sel = null; rebuildWidgets(); }).bounds(x0 + 102, y0 + 8, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Inchide"), b -> onClose()).bounds(x0 + 384, y0 + 8, 48, 20).build());
        if (sel == null) return;
        int px = x0 + 300;
        if (shop) {
            long price = Garage.PRICE.getOrDefault(sel, 0L);
            if (price > 0)
                addRenderableWidget(Button.builder(Component.literal("CUMPARA $" + String.format("%,d", price)), b -> send(4)).bounds(px, y0 + 150, 128, 20).build());
        } else {
            var en = find(sel);
            if (en != null && en.out) {
                addRenderableWidget(Button.builder(Component.literal("PARCHEAZA"), b -> send(2)).bounds(px, y0 + 150, 128, 20).build());
            } else if (en != null) {
                addRenderableWidget(Button.builder(Component.literal("SCOATE"), b -> send(1)).bounds(px, y0 + 150, 128, 20).build());
                addRenderableWidget(Button.builder(Component.literal("VINDE (60%)"), b -> send(3)).bounds(px, y0 + 174, 128, 20).build());
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        List<String> l = ids();
        for (int i = 0; i < l.size(); i++) {
            int cx = x0() + 8 + (i % 4) * 72, cy = y0() + 34 + (i / 4) * 48;
            if (mx >= cx && mx < cx + 68 && my >= cy && my < cy + 44) { sel = l.get(i); rebuildWidgets(); return true; }
        }
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x0 = x0(), y0 = y0();
        Panel.draw(g, x0, y0, 440, 240);
        List<String> l = ids();
        for (int i = 0; i < l.size(); i++) {
            String id = l.get(i);
            int cx = x0 + 8 + (i % 4) * 72, cy = y0 + 34 + (i / 4) * 48;
            g.fill(cx, cy, cx + 68, cy + 44, 0xFF1A1236);
            g.renderOutline(cx, cy, 68, 44, id.equals(sel) ? 0xFFFFD36B : 0xFF4A3A8F);
            ItemStack ic = icon(id);
            if (!ic.isEmpty()) g.renderItem(ic, cx + 26, cy + 4);
            g.drawString(font, font.plainSubstrByWidth(nameOf(id), 64), cx + 3, cy + 30, 0xFFFFFFFF, false);
            var en = find(id);
            if (!shop && en != null && en.out) g.drawString(font, "AFARA", cx + 3, cy + 3, 0xFFFF5577, false);
        }
        if (l.isEmpty()) g.drawString(font, shop ? "Nimic de vandut." : "Garajul e gol. Cumpara din MAGAZIN.", x0 + 12, y0 + 44, 0xFFA99BE0, false);
        if (sel != null) {
            int px = x0 + 300;
            g.drawString(font, font.plainSubstrByWidth(nameOf(sel), 128), px, y0 + 38, 0xFFB79CFF, false);
            long price = Garage.PRICE.getOrDefault(sel, 0L);
            g.drawString(font, price > 0 ? "Pret: $" + String.format("%,d", price) : "Doar staff", px, y0 + 52, 0xFFFFD36B, false);
            ItemStack ic = icon(sel);
            if (!ic.isEmpty()) {
                var pose = g.pose();
                pose.pushPose();
                pose.translate(px + 40, y0 + 70, 0);
                pose.scale(3f, 3f, 1f);
                g.renderItem(ic, 0, 0);
                pose.popPose();
            }
            g.drawString(font, "Banca: $" + String.format("%,d", ClientData.bank), px, y0 + 132, 0xFF7CFF8A, false);
        }
        super.render(g, mx, my, pt);
    }
}
