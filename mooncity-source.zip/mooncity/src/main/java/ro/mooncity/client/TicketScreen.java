package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ro.mooncity.Net;
import ro.mooncity.TicketPacket;

public class TicketScreen extends Screen {
    private String type = "INTREBARE", tTitle = "", tDesc = "";
    private EditBox title;
    private MultiLineEditBox desc;

    public TicketScreen() { super(Component.literal("Ticket")); }

    private void save() { if (title != null) { tTitle = title.getValue(); tDesc = desc.getValue(); } }

    @Override
    protected void init() {
        int x0 = width / 2 - 170, y = Math.max(8, height / 2 - 125);
        String[] types = {"INTREBARE", "RAPORT", "BUG"};
        for (int i = 0; i < 3; i++) {
            String t = types[i];
            addRenderableWidget(Button.builder(Component.literal(t.equals(type) ? "> " + t : t), b -> { save(); type = t; rebuildWidgets(); })
                    .bounds(x0 + i * 116, y, 108, 20).build());
        }
        title = new EditBox(font, x0, y + 28, 340, 20, Component.literal("Titlu"));
        title.setMaxLength(60);
        title.setHint(Component.literal("Titlu"));
        title.setValue(tTitle);
        addRenderableWidget(title);
        desc = new MultiLineEditBox(font, x0, y + 54, 340, 110, Component.literal("Descrie problema in detaliu..."), Component.empty());
        desc.setCharacterLimit(400);
        desc.setValue(tDesc);
        addRenderableWidget(desc);
        addRenderableWidget(Button.builder(Component.literal("TRIMITE TICKET"), b -> {
            save();
            if (tTitle.isBlank() || tDesc.isBlank()) return;
            Net.CH.sendToServer(new TicketPacket(type, tTitle, tDesc));
            onClose();
        }).bounds(x0 + 80, y + 172, 180, 20).build());
        addRenderableWidget(Button.builder(Component.literal("ANULEAZA CEREREA"), b -> onClose()).bounds(x0 + 80, y + 196, 180, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        int y = Math.max(8, height / 2 - 125);
        g.drawString(font, (400 - (desc == null ? 0 : desc.getValue().length())) + " caractere ramase", width / 2 + 60, y + 166, 0xFFA99BE0, false);
    }
}
