package ro.mooncity.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class InteractScreen extends Screen {
    private EditBox amount;
    public InteractScreen() { super(Component.literal("Interactiuni")); }

    @Override
    protected void init() {
        int w = 220, x = width / 2 - w / 2, y = height / 2 - 50;
        addRenderableWidget(Button.builder(Component.literal("Da mana"), b -> { Cmd.run("interact handshake"); onClose(); }).bounds(x, y, w, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Arata buletinul"), b -> { Cmd.run("interact id"); onClose(); }).bounds(x, y + 26, w, 22).build());
        amount = new EditBox(font, x, y + 56, 110, 20, Component.literal("Suma"));
        amount.setHint(Component.literal("Suma ($)"));
        amount.setMaxLength(9);
        addRenderableWidget(amount);
        addRenderableWidget(Button.builder(Component.literal("Da bani"), b -> {
            String v = amount.getValue().trim();
            if (v.matches("\\d{1,9}")) { Cmd.run("interact pay " + v); onClose(); }
        }).bounds(x + 114, y + 56, 106, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Inapoi"), b -> minecraft.setScreen(new MenuScreen())).bounds(x, y + 84, w, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Panel.draw(g, width / 2 - 120, height / 2 - 80, 240, 190);
        g.drawCenteredString(font, "INTERACTIUNI (jucator din apropiere)", width / 2, height / 2 - 70, 0xFFB79CFF);
        super.render(g, mx, my, pt);
    }
}
