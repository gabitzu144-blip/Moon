package ro.mooncity.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ro.mooncity.MoonCity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MoonHud {
    private static final ResourceLocation MOON = new ResourceLocation(MoonCity.MODID, "textures/gui/moon.png");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private static final int BG = 0xC0120C28;
    private static final int BORDER = 0xFF7B5CE6;
    private static final int LABEL = 0xFFA99BE0;
    private static final int WHITE = 0xFFFFFFFF;
    private static long lastSec;
    private static String cachedTime = "";

    @Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Register {
        @SubscribeEvent
        public static void overlays(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("mooncity_hud", (gui, g, partial, w, h) -> render(g, w, h));
        }
    }

    @Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class HideVanilla {
        @SubscribeEvent
        public static void pre(RenderGuiOverlayEvent.Pre e) {
            var o = e.getOverlay();
            if (o == VanillaGuiOverlay.PLAYER_HEALTH.type() || o == VanillaGuiOverlay.ARMOR_LEVEL.type()
                    || o == VanillaGuiOverlay.FOOD_LEVEL.type()) {
                e.setCanceled(true);
            }
        }
    }

    private static int box(GuiGraphics g, Font f, int rightX, int y, String label, String value, int color) {
        int w = Math.max(f.width(label), f.width(value)) + 12;
        int x = rightX - w;
        g.fill(x, y, x + w, y + 26, BG);
        g.renderOutline(x, y, w, 26, BORDER);
        g.drawString(f, label, x + 6, y + 4, LABEL, false);
        g.drawString(f, value, x + 6, y + 14, color, false);
        return x - 4;
    }

    private static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.options.hideGui) return;
        Font f = mc.font;

        // logo luna
        g.blit(MOON, w - 36, 4, 0, 0, 32, 32, 32, 32);

        // randul de sus
        int x = w - 40;
        long sec = System.currentTimeMillis() / 1000;
        if (sec != lastSec) { lastSec = sec; cachedTime = LocalDateTime.now().format(FMT); }
        String time = cachedTime;
        long ps = ClientData.playSeconds;
        x = box(g, f, x, 6, "ORA", time, WHITE);
        x = box(g, f, x, 6, "ONLINE", String.valueOf(ClientData.online), WHITE);
        x = box(g, f, x, 6, "ID", "#" + ClientData.id, 0xFFB79CFF);
        x = box(g, f, x, 6, "JUCAT", (ps / 3600) + "h " + ((ps % 3600) / 60) + "m", WHITE);
        if (ClientData.duty) box(g, f, x, 6, "SERVICIU", "ON DUTY", 0xFF55FF55);

        // cash + bank
        box(g, f, w - 6, 40, "CASH", "$" + String.format("%,d", ClientData.cash), 0xFF7CFF8A);
        box(g, f, w - 6, 70, "BANK", "$" + String.format("%,d", ClientData.bank), 0xFFFFD36B);

        if (ClientData.nearGarage)
            g.drawCenteredString(f, "Apasa [O] pentru a deschide garajul", w / 2, h - 70, 0xFFFFD36B);

        // status jos-stanga
        int hp = Math.round(p.getHealth() / p.getMaxHealth() * 100);
        int ar = Math.round(p.getArmorValue() / 20f * 100);
        int fd = Math.round(p.getFoodData().getFoodLevel() / 20f * 100);
        stat(g, f, 8, h - 34, "HP", hp, 0xFFFF5577);
        stat(g, f, 50, h - 34, "ARMURA", ar, 0xFF77AAFF);
        stat(g, f, 100, h - 34, "MANCARE", fd, 0xFFFFB655);
    }

    private static void stat(GuiGraphics g, Font f, int x, int y, String label, int pct, int color) {
        pct = Math.max(0, Math.min(100, pct));
        int w = Math.max(f.width(label), f.width("100%")) + 10;
        g.fill(x, y, x + w, y + 28, BG);
        g.renderOutline(x, y, w, 28, BORDER);
        g.drawString(f, label, x + 5, y + 3, LABEL, false);
        g.drawString(f, pct + "%", x + 5, y + 13, color, false);
        g.fill(x + 3, y + 24, x + 3 + (w - 6) * pct / 100, y + 26, color);
    }
}
