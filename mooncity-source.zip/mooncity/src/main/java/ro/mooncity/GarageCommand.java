package ro.mooncity;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class GarageCommand {
    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("garage")
                .then(literal("give").requires(s -> s.hasPermission(2))
                        .then(argument("jucator", EntityArgument.player())
                                .then(argument("masina", StringArgumentType.word())
                                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Garage.PRICE.keySet(), b))
                                        .executes(c -> {
                                            ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                                            String id = StringArgumentType.getString(c, "masina");
                                            if (!Garage.PRICE.containsKey(id)) { c.getSource().sendFailure(Component.literal("Masina necunoscuta.")); return 0; }
                                            PlayerData.addCar(t, id);
                                            c.getSource().sendSuccess(() -> Component.literal("I-ai dat " + id + " lui " + t.getName().getString()), true);
                                            return 1;
                                        }))))
                .then(literal("buy").then(argument("masina", StringArgumentType.word())
                        .suggests((ctx, b) -> SharedSuggestionProvider.suggest(Garage.PRICE.keySet(), b))
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            String err = Garage.buy(p, StringArgumentType.getString(c, "masina"));
                            if (err != null) { c.getSource().sendFailure(Component.literal(err)); return 0; }
                            Net.sync(p);
                            c.getSource().sendSuccess(() -> Component.literal("Masina a fost adaugata in garaj."), false);
                            return 1;
                        }))));
    }
}
