package ro.mooncity;

import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class AdminCommands {
    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("respawn").requires(s -> s.hasPermission(2))
                .then(argument("jucator", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                    ServerLevel w = t.server.overworld();
                    BlockPos sp = w.getSharedSpawnPos();
                    t.teleportTo(w, sp.getX() + 0.5, sp.getY(), sp.getZ() + 0.5, 0, 0);
                    return 1;
                })));
        e.getDispatcher().register(literal("stats").requires(s -> s.hasPermission(2))
                .then(argument("jucator", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                    String grad = PlayerData.prefix(t).isEmpty() ? "-" : PlayerData.prefix(t);
                    String m = t.getName().getString() + " | ID #" + PlayerData.id(t) + " | Grad: " + grad
                            + " | Duty: " + (PlayerData.duty(t) ? "ON" : "OFF")
                            + " | Cash $" + PlayerData.cash(t) + " | Bank $" + PlayerData.bank(t)
                            + " | HP " + Math.round(t.getHealth());
                    c.getSource().sendSuccess(() -> Component.literal(m), false);
                    return 1;
                })));
    }
}
