package ro.mooncity;

import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class UniformCommand {
    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("polkit").requires(s -> s.hasPermission(2))
                .then(argument("jucator", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "jucator");
                    Uniform.give(t);
                    c.getSource().sendSuccess(() -> Component.literal("Kit politie dat lui " + t.getName().getString()), true);
                    return 1;
                })));
    }
}
