package ro.mooncity;

import com.mojang.brigadier.arguments.LongArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class InteractCommand {
    private static ServerPlayer nearest(ServerPlayer p) {
        ServerPlayer best = null; double bd = 16.0; // 4 blocuri
        for (ServerPlayer o : p.server.getPlayerList().getPlayers()) {
            if (o == p || o.level() != p.level()) continue;
            double d = o.distanceToSqr(p);
            if (d < bd) { bd = d; best = o; }
        }
        return best;
    }

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(literal("interact")
                .then(literal("handshake").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException(); ServerPlayer t = nearest(p);
                    if (t == null) return none(p);
                    p.sendSystemMessage(Component.literal("I-ai dat mana lui " + t.getName().getString()).withStyle(ChatFormatting.LIGHT_PURPLE));
                    t.sendSystemMessage(Component.literal(p.getName().getString() + " ti-a dat mana.").withStyle(ChatFormatting.LIGHT_PURPLE));
                    return 1;
                }))
                .then(literal("id").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException(); ServerPlayer t = nearest(p);
                    if (t == null) return none(p);
                    String grad = PlayerData.prefix(p).isEmpty() ? "Civil" : PlayerData.prefix(p);
                    t.sendSystemMessage(Component.literal("[Buletin] " + p.getName().getString() + " | ID #" + PlayerData.id(p) + " | " + grad).withStyle(ChatFormatting.AQUA));
                    p.sendSystemMessage(Component.literal("Ai aratat buletinul lui " + t.getName().getString()).withStyle(ChatFormatting.AQUA));
                    return 1;
                }))
                .then(literal("pay").then(argument("suma", LongArgumentType.longArg(1)).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException(); ServerPlayer t = nearest(p);
                    if (t == null) return none(p);
                    long v = LongArgumentType.getLong(c, "suma");
                    if (PlayerData.cash(p) < v) { p.sendSystemMessage(Component.literal("Nu ai destul cash.").withStyle(ChatFormatting.RED)); return 0; }
                    PlayerData.setCash(p, PlayerData.cash(p) - v);
                    PlayerData.setCash(t, PlayerData.cash(t) + v);
                    Net.sync(p); Net.sync(t);
                    p.sendSystemMessage(Component.literal("I-ai dat $" + v + " lui " + t.getName().getString()).withStyle(ChatFormatting.GREEN));
                    t.sendSystemMessage(Component.literal("Ai primit $" + v + " de la " + p.getName().getString()).withStyle(ChatFormatting.GREEN));
                    return 1;
                }))));
    }

    private int none(ServerPlayer p) {
        p.sendSystemMessage(Component.literal("Nu e nimeni aproape (4 blocuri).").withStyle(ChatFormatting.RED));
        return 0;
    }
}
