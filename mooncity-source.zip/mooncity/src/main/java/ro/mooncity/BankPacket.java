package ro.mooncity;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** op: 0 depune, 1 retrage, 2 transfer IBAN (din telefon / ATM) */
public class BankPacket {
    public final int op; public final long amount; public final String iban;
    public BankPacket(int op, long amount, String iban) { this.op = op; this.amount = amount; this.iban = iban; }
    public static void encode(BankPacket p, FriendlyByteBuf b) { b.writeInt(p.op); b.writeLong(p.amount); b.writeUtf(p.iban, 40); }
    public static BankPacket decode(FriendlyByteBuf b) { return new BankPacket(b.readInt(), b.readLong(), b.readUtf(40)); }

    public static void handle(BankPacket p, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sp = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (sp == null) return;
            // ATM (op 0/1) cere sa fii langa un ATM; telefonul (op 2) cere telefonul in mana
            String err;
            switch (p.op) {
                case 0 -> err = nearAtm(sp) ? Bank.deposit(sp, p.amount) : "Nu esti langa un ATM.";
                case 1 -> err = nearAtm(sp) ? Bank.withdraw(sp, p.amount) : "Nu esti langa un ATM.";
                case 2 -> err = hasPhone(sp) || nearAtm(sp) ? Bank.transfer(sp, p.iban, p.amount) : "Ai nevoie de telefon.";
                default -> err = "Operatie necunoscuta.";
            }
            sp.sendSystemMessage(err == null
                    ? Component.literal("Operatiune reusita.").withStyle(ChatFormatting.GREEN)
                    : Component.literal(err).withStyle(ChatFormatting.RED));
        });
        ctx.get().setPacketHandled(true);
    }

    private static boolean hasPhone(ServerPlayer sp) {
        return sp.getMainHandItem().is(MoonCity.PHONE.get()) || sp.getOffhandItem().is(MoonCity.PHONE.get());
    }

    private static boolean nearAtm(ServerPlayer sp) {
        var pos = sp.blockPosition();
        for (var b : net.minecraft.core.BlockPos.betweenClosed(pos.offset(-5, -3, -5), pos.offset(5, 3, 5)))
            if (sp.level().getBlockState(b).is(MoonCity.ATM.get())) return true;
        return false;
    }
}
