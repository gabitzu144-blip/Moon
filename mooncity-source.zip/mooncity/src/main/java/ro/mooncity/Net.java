package ro.mooncity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MoonCity.MODID, "main"), () -> V, V::equals, V::equals);

    private Net() {}

    public static void init() {
        CH.registerMessage(0, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
        CH.registerMessage(1, TicketPacket.class, TicketPacket::encode, TicketPacket::decode, TicketPacket::handle);
        CH.registerMessage(2, RequestTicketsPacket.class, RequestTicketsPacket::encode, RequestTicketsPacket::decode, RequestTicketsPacket::handle);
        CH.registerMessage(4, BankPacket.class, BankPacket::encode, BankPacket::decode, BankPacket::handle);
        CH.registerMessage(5, OpenScreenPacket.class, OpenScreenPacket::encode, OpenScreenPacket::decode, OpenScreenPacket::handle);
        CH.registerMessage(3, TicketListPacket.class, TicketListPacket::encode, TicketListPacket::decode, TicketListPacket::handle);
        CH.registerMessage(6, GarageActionPacket.class, GarageActionPacket::encode, GarageActionPacket::decode, GarageActionPacket::handle);
        CH.registerMessage(7, GarageListPacket.class, GarageListPacket::encode, GarageListPacket::decode, GarageListPacket::handle);
        CH.registerMessage(8, JobOpenPacket.class, JobOpenPacket::encode, JobOpenPacket::decode, JobOpenPacket::handle);
        CH.registerMessage(9, JobPacket.class, JobPacket::encode, JobPacket::decode, JobPacket::handle);
    }

    public static void sync(ServerPlayer sp) {
        int play = sp.getStats().getValue(Stats.CUSTOM.get(Stats.PLAY_TIME)) / 20;
        CH.send(PacketDistributor.PLAYER.with(() -> sp), new SyncPacket(
                PlayerData.id(sp), PlayerData.cash(sp), PlayerData.bank(sp), PlayerData.duty(sp),
                sp.server.getPlayerCount(), play));
    }
}
