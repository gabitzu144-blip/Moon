package ro.mooncity;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(MoonCity.MODID)
public class MoonCity {
    public static final String MODID = "mooncity";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final RegistryObject<Block> ATM = BLOCKS.register("atm",
            () -> new AtmBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(3.0F, 1200.0F)));
    public static final RegistryObject<Item> ATM_ITEM = ITEMS.register("atm", () -> new BlockItem(ATM.get(), new Item.Properties()));
    public static final RegistryObject<Block> GARAGE = BLOCKS.register("garage",
            () -> new GarageBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_YELLOW).strength(3.0F, 1200.0F)));
    public static final RegistryObject<Item> GARAGE_ITEM = ITEMS.register("garage", () -> new BlockItem(GARAGE.get(), new Item.Properties()));
    public static final RegistryObject<Item> POLICE_CAP = ITEMS.register("police_cap",
            () -> new ArmorItem(PoliceMaterial.SHIRT, ArmorItem.Type.HELMET, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> POLICE_SHIRT = ITEMS.register("police_shirt",
            () -> new ArmorItem(PoliceMaterial.SHIRT, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> POLICE_VEST = ITEMS.register("police_vest",
            () -> new ArmorItem(PoliceMaterial.VEST, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> POLICE_PANTS = ITEMS.register("police_pants",
            () -> new ArmorItem(PoliceMaterial.SHIRT, ArmorItem.Type.LEGGINGS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> POLICE_BOOTS = ITEMS.register("police_boots",
            () -> new ArmorItem(PoliceMaterial.SHIRT, ArmorItem.Type.BOOTS, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> PHONE = ITEMS.register("phone", () -> new PhoneItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> MEDKIT =
            ITEMS.register("medkit", () -> new MedkitItem(new Item.Properties().stacksTo(16)));

    public MoonCity() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        BLOCKS.register(bus);
        bus.addListener(this::tab);
        bus.addListener((net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent ev) -> ev.enqueueWork(Net::init));
        MinecraftForge.EVENT_BUS.register(new Events());
        MinecraftForge.EVENT_BUS.register(new Commands());
        MinecraftForge.EVENT_BUS.register(new MoneyCommand());
        MinecraftForge.EVENT_BUS.register(new TicketCommand());
        MinecraftForge.EVENT_BUS.register(new InteractCommand());
        MinecraftForge.EVENT_BUS.register(new AdminCommands());
        MinecraftForge.EVENT_BUS.register(new JailCommand());
        MinecraftForge.EVENT_BUS.register(new GarageCommand());
        MinecraftForge.EVENT_BUS.register(new VehicleLock());
        MinecraftForge.EVENT_BUS.register(new NpcCommand());
        MinecraftForge.EVENT_BUS.register(new UniformCommand());
    }

    private void tab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) { e.accept(MEDKIT); e.accept(PHONE); e.accept(ATM_ITEM); e.accept(GARAGE_ITEM);
            e.accept(POLICE_CAP); e.accept(POLICE_SHIRT); e.accept(POLICE_VEST); e.accept(POLICE_PANTS); e.accept(POLICE_BOOTS); }
    }
}
